# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['page-analyzer']

package_data = \
{'': ['*'], 'page-analyzer': ['templates/*']}

install_requires = \
['Flask>=3.0.3,<4.0.0',
 'bs4>=0.0.2,<0.0.3',
 'gunicorn>=22.0.0,<23.0.0',
 'psycopg2-binary>=2.9.9,<3.0.0',
 'psycopg>=3.1.18,<4.0.0',
 'python-dotenv>=1.0.1,<2.0.0',
 'requests>=2.31.0,<3.0.0',
 'urllib3==1.26.15',
 'validators>=0.28.1,<0.29.0']

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': '',
    'long_description': None,
    'author': 'Your Name',
    'author_email': 'you@example.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
